/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

// State Machine States
enum SM_States {SOS_Start, SOS_R_Off, SOS_R_On, SOS_G_Off, SOS_G_On, OK_R_On, OK_R_Off, OK_G_On, OK_G_Off, SOS_Char_Timeout, SOS_Word_Timeout } SM_State;

volatile unsigned char TimerFlag;       // Timer flag for ISR
static unsigned char which_message = 0; // Static variable to alternate between SOS / OK
static unsigned char change_flag = 0;   // Buffer variable to alert the main function to change upon interrupt

void TimerISR() {
    TimerFlag = 1;
    if (change_flag == 1) {             // If-else to toggle back and forth between messages
        if (which_message == 0) {
            which_message = 1;
        } else {
            which_message = 0;
        }
    }
    change_flag = 0;
}
void buffer_message() {         // Function to buffer message change upon message completion
    change_flag = 1;
}
/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)        // Button functionality
{
    buffer_message();
}


/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{
    buffer_message();
}


void turnLightOn(int index)     // Function to turn on light, accepts parameter of 0 or 1 to determine which light
{
    if (index == 0)
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    if (index == 1)
        GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);

}
void turnLightOff(int index)    // // Function to turn off light, accepts parameter of 0 or 1 to determine which light
{
    if (index == 0)
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);

    if (index == 1)
        GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);

}

void timerCallback(Timer_Handle myHandle, int_fast16_t status)      // Callback function to interrupt
{
    TimerISR();
}

void initTimer(void)    // Provided code
{

    Timer_Handle timer0;
    Timer_Params params;

    Timer_init();
    Timer_Params_init(&params);
    params.period = 500000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    if (timer0 == NULL) {
        /* Failed to initialized timer */
        while (1) {}
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
     /* Failed to start timer */
     while (1) {}
     }

}

void TickFct_SOS() {            // State Machine

    static unsigned char cnt;               // Counter for dots / dashes
    static unsigned char wait_cnt = 0;      // Counter for keeping light on
    static unsigned char letter_index = 0;  // Index to tell SM which letter we are on
    static unsigned char curr_state = 0;    // Variable to communicate which message we are sending

    switch (SM_State) {  // Transitions

        case SOS_Start:             // Initialize
            cnt = 0;                // Define cnt
            SM_State = SOS_R_On;   // Start with On
            break;
        case SOS_R_Off:
            if (cnt < 3) {          // If we haven't dotted 3 times...
                SM_State = SOS_R_On;    // Turn on R Light
            }
            else if (letter_index < 2)  // If we have dotted 3 times, and it's only the first S
            {
                SM_State = SOS_Char_Timeout;        // We go to Char timeout (3 * 500 ms)
                letter_index = 1;                     // Increment our letter ID (0, 1, 2 :: S, O, S)
                cnt = 0;                            // Make sure our cnt is reset
            } else {                        // OTHERWISE (we finished our second S)
                SM_State = SOS_Word_Timeout;    // We go to our longer timeout
                letter_index = 0;               // Reset our letter index back to 0
                cnt = 0;                        // Reset our dot/dash counter to 0
                wait_cnt = 0;                   // Reset our time counter to 0
            }
            break;
        case SOS_R_On:                  // If it's on, we turn it off. Increment on the turn off
            SM_State = SOS_R_Off;
            break;
        case SOS_G_On:                  // If our green light is on...
            if (wait_cnt < 3) {         // We need to hold it for 1500 ms (3 * 500 ms)
                SM_State = SOS_G_On;    // Keep it on
            }
            else {                      // Otherwise, we're done holding it
                SM_State = SOS_G_Off;   // Turn it off
                wait_cnt = 0;           // Reset our iteration counter
            }
            break;
        case SOS_G_Off:                 // If green is OFF...
            if (cnt < 3) {              // And we haven't blinked 3 times..
                SM_State = SOS_G_On;    // Turn it back on
            }
            else {                   // Otherwise, the next letter is guaranteed to be S again
                SM_State = SOS_Char_Timeout;    // But we have to wait the 1500 ms
                cnt = 0;                        // Reset our count
                letter_index++;                // Increment our index to 1 (i = 0)
            }
            break;
        case OK_R_On:                   // The only R flash is in K (- . -), and it happens once
            SM_State = OK_R_Off;        // So we can just turn it off
            break;
        case OK_R_Off:
            SM_State = OK_G_On;         // We only do this once, so cnt++ (to 1)
            break;
        case OK_G_Off:                  // Here we had to get a little messy
            if (letter_index == 3)      // Letter index 3 refers to K (0, 1, 2: SOS, 3: K)
            {
                if (cnt < 1) {          // If we haven't blinked once
                    SM_State = OK_G_On; // Let's blink once
                } else {
                    SM_State = OK_R_On; // Otherwise cnt == 1, and we must reset it, and refer to a new index
                    cnt = 0;
                    letter_index = 4;   // Index 4 is a cheap workaround to use our OK_G_Off twice, and refers to our 3 dash
                }
            }
            else if (letter_index == 4)   // If we are ready for our 3rd dash...
            {
                if (cnt < 1) {              // and we haven't done it yet...
                    SM_State = OK_G_On;     // Turn it on
                } else {
                    SM_State = SOS_Word_Timeout;    // Otherwise, we're done with the word
                    wait_cnt = 0;
                    cnt = 0;                        // Reset our counter
                    letter_index = 0;               // Reset our index
                }
            }
             else if (cnt < 3)
            {                                   // OTHERWISE, this is our first O; And we haven't blinked 3 times..
                SM_State = OK_G_On;            // Turn it back on
            }
            else {                              // Otherwise, it's time to communicate our K
                SM_State = SOS_Char_Timeout;    // But we have to wait the 1500 ms
                cnt = 0;                        // Reset our count
                letter_index = 3;                // Set our index to 3 (3: K)
            }
            break;
        case OK_G_On:                           // If our G is on...
            if (letter_index == 3) {            // And we're working on K...
                if (wait_cnt < 3) {             // We gotta wait the full 1500ms to assert a dash
                    SM_State = OK_G_On;         // So keep it on
                } else {
                    SM_State = OK_G_Off;        // Otherwise, turn it off
                    wait_cnt = 0;               // Reset our wait counter
                }
            } else if (letter_index == 4) {     // If we're on our final dash in K (- . -)...
                if (wait_cnt < 3) {             // Make sure we keep it on for 1500 ms
                    SM_State = OK_G_On;
                } else {
                    SM_State = SOS_Word_Timeout;    // Otherwise, we're done with the word. Set state to Timeout
                    wait_cnt = 0;               // Make sure all our housekeeping variables are reset
                    letter_index = 0;
                    cnt = 0;
                }
            }
            else if (wait_cnt < 3) {   // If letter_index is 0 (AKA O in OK)...
                SM_State = OK_G_On;    // Keep it on for 3 rounds
            }
            else {                      // Otherwise, we're done holding it
                SM_State = OK_G_Off;    // Turn it off
                wait_cnt = 0;           // Reset our iteration counter
            }
            break;
        case SOS_Char_Timeout:          // If we are on character timeout...
            if (wait_cnt < 3) {         // If we haven't cycled three times yet..
                SM_State = SOS_Char_Timeout; // Keep it in timeout
            } else if ((letter_index == 0) || (letter_index == 2)) {     // Otherwise, if our letter index is either 0 or 2 (S)..
                wait_cnt = 0;                   // Reset our waiting counter
                SM_State = SOS_R_On;         // Then our next letter is going to be S
            } else if (letter_index == 3) {     // Index 3 tells us we're actually in our OK routine
                wait_cnt = 0;                   // Make sure our variable is reset
                SM_State = OK_G_On;        // Move on to K
            }
            else {
                wait_cnt = 0;               // Otherwise, it's only our first S, and O comes next
                SM_State = SOS_G_On;
            }
            break;
        case SOS_Word_Timeout:              // Longer timeout at completion of message
            if (wait_cnt < 7) {             // 7 * 500 ms = 3500 ms per rubric
                SM_State = SOS_Word_Timeout;    // Stay in state as long as we haven't completed
            } else {
                curr_state = which_message;     // Once we're done waiting, re-assign our state variable to our global message index
                if (curr_state == 0) {      // If we're still in SOS...
                    SM_State = SOS_R_On;        // Start with SOS_R
                    wait_cnt = 0;               // Reset our waiting
                }
                else {
                    SM_State = OK_G_On;         // Otherwise, curr_state is 1, and we're relaying OK
                    wait_cnt = 0;               // Reset our counter
                }
            }
            break;
        default:
            break;
    }

    switch (SM_State) {     // State actions

        case SOS_R_Off:
            turnLightOff(0);    // Turn off, +1 Dot
            cnt++;
            break;
        case SOS_R_On:
            turnLightOn(0);
            break;
        case SOS_G_Off:
            turnLightOff(1);    // Turn off, +1 Dash
            cnt++;
            break;
        case SOS_G_On:
            turnLightOn(1);     // Turn on (or keep on), +1 wait counter
            wait_cnt++;
            break;
        case OK_R_Off:
            turnLightOff(0);    // Turn off our R light
            cnt++;              // Count it once
            break;
        case OK_R_On:
            turnLightOn(0);     // Just turn it on
            break;
        case OK_G_Off:
            turnLightOff(1);    // Turn it off
            cnt++;              // Count it once
            break;
        case OK_G_On:           // Turn it on
            turnLightOn(1);     // Only count when off
            wait_cnt++;
            break;
        case SOS_Char_Timeout:
            turnLightOff(0);    // Ensure both lights are off, +1 wait counter
            turnLightOff(1);
            wait_cnt++;
            break;
        case SOS_Word_Timeout:
            turnLightOff(0);    // Ensure both lights are off, +1 wait counter
            turnLightOff(1);    // Probably could have copied our timeout cases, but wanted it to be very apparent
            wait_cnt++;
            break;
        default:
            break;
    }


}


/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{



    /* Call driver init functions */
    GPIO_init();
    initTimer();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);


    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    SM_State = SOS_Start;   // Initialize our state machine

    while (1) {                 // Run our state machine
        TickFct_SOS();
        while (!TimerFlag) {}
        TimerFlag = 0;
    }

}
